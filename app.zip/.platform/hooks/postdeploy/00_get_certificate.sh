#!/usr/bin/env bash
# Place in .platform/hooks/postdeploy directory
sudo certbot -n -d htwf-anauman2.is404.net --nginx --agree-tos --email andnau702@gmail.com